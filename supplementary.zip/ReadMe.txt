The extra data for the paper Regression via Kirszbraun Extension with Applications to
Imitation Learning organized as follows:

1. python code: The implementation of the algorithm in pyhon, with the additional matlab functions neede. the functions are called from within the python code

2. Matlab functions: The matlab fucntion which we generated the data with.

3. figures: Extra figures of the 20 first test points included, which demonstrates the MWU algorithm learns "better" the correspondence funtion also visualy.

4. data: all the data we generated for this problem for further exploration. 

5. Appendix


Each folder may consists another ReadMe file with more relevant details.